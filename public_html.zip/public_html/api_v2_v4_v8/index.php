<?php
@mysql_connect("localhost","zeroloss","C2b40Lj6uj");
mysql_select_db("zeroloss_123");
if(isset($_GET["emirler"])){
	$emirler = file_get_contents("php://input");
	$emirler = json_decode($emirler, true);
	$market = str_replace(" ","",$emirler["orders"]["sell"]["market"]);
	$fiyat = file_get_contents("https://bittrex.com/api/v1.1/public/getticker?market=".$market);
	$fiyat = json_decode($fiyat, true);
	$bid = number_format($fiyat["result"]["Bid"],8);
	$ask = number_format($fiyat["result"]["Ask"],8);
	$last = number_format($fiyat["result"]["Last"],8);
	echo $bid."\n";
	echo $ask."\n";
	echo $last."\n";
}else{
if(isset($_GET['bot'])&&isset($_GET['api_key'])&&isset($_GET['api_secret'])&&isset($_GET['type'])){
/* EMİRLERİ ALMA */

function bittrex($apikey, $apisecret, $orders, $paskey, $yerine_gec="hayir"){
if($yerine_gec=="hayir"){
if(mysql_num_rows(mysql_query("select * from orders where passkey='".$paskey."'"))<5){
$market = str_replace(" ","",$orders["orders"]["sell"]["market"]);
$nonce=time();
$uri='https://bittrex.com/api/v1.1/market/getopenorders?apikey='.$apikey.'&nonce='.$nonce.'&market='.$market;
$sign=hash_hmac('sha512',$uri,$apisecret);
$ch = curl_init($uri);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('apisign:'.$sign));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$execResult = curl_exec($ch);
$bb = json_decode($execResult, true);
$emirvarmi = "yok";
if(count($bb["result"])!=0){
	echo "Zaten seçilen coin için emirleriniz var, iptal edilsinlermi?";
	$emirvarmi = "var";
}
else{
	$market = str_replace(" ","",$orders["orders"]["sell"]["market"]);
	$ordercontrol = "select market from orders where market = '$market' and passkey = '$paskey'";
	if(mysql_num_rows(mysql_query($ordercontrol))!=0&&$emirvarmi=="yok"){echo "Zaten seçilen coin için emirleriniz var, iptal edilsinlermi?";}
	else{
	$neworders = serialize($orders);
	$market = mysql_real_escape_string($orders["orders"]["sell"]["market"]);
	$deletesql = mysql_query("DELETE FROM orders WHERE market = '$market' and passkey = '$paskey'");
	$insertsql = mysql_query("insert into orders(id,passkey,market,raw_order) values (NULL,'$paskey','$market','$neworders')");
	if($insertsql&&$deletesql){
		echo "emir eklendi";
	}
	}
}
}else if(mysql_num_rows(mysql_query("select * from orders where passkey='".$paskey."'"))==5){
	$ssql = mysql_query("select * from orders where passkey='".mysql_real_escape_string($paskey)."'");
	if(mysql_num_rows($ssql)!=0){
		while($oku = mysql_fetch_array($ssql)){
			if(str_replace(" ","",$orders["orders"]["sell"]["market"])==$oku["market"]){
				echo "Zaten";
			}
		}
	}
	
	echo "limit_doldu";
}else{echo "limitle_ilgili_sorun";}
}
else if($yerine_gec == "evet"){
if(mysql_num_rows(mysql_query("select * from orders where passkey='".$orders."'"))<5){
$market = str_replace(" ","",$orders["orders"]["sell"]["market"]);
$nonce=time();
$uri='https://bittrex.com/api/v1.1/market/getopenorders?apikey='.$apikey.'&nonce='.$nonce.'&market='.$market;
$sign=hash_hmac('sha512',$uri,$apisecret);
$ch = curl_init($uri);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('apisign:'.$sign));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$execResult = curl_exec($ch);
$bb = json_decode($execResult, true);
if(count($bb["result"])!=0){
	$uuids = array();
	for($a=0;$a<=count($bb["result"])-1;$a++){
		array_push($uuids, $bb["result"][$a]["OrderUuid"]);
	}
	foreach($uuids as $uuid){
		$nonce2=time();
		$uri2='https://bittrex.com/api/v1.1/market/cancel?apikey='.$apikey.'&nonce='.$nonce.'&uuid='.$uuid;
		$sign2=hash_hmac('sha512',$uri2,$apisecret);
		$ch2 = curl_init($uri2);
		curl_setopt($ch2, CURLOPT_HTTPHEADER, array('apisign:'.$sign2));
		curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
		$execResult2 = curl_exec($ch2);
		$bb2 = json_decode($execResult2, true);
		
	}
	$neworders = serialize($orders);
	$market = mysql_real_escape_string($orders["orders"]["sell"]["market"]);
	$deletesql = mysql_query("DELETE FROM orders WHERE market = '$market' and passkey = '$paskey'");
	$insertsql = mysql_query("insert into orders(id,passkey,market,raw_order) values (NULL,'$paskey','$market','$neworders')");
	if($insertsql&&$deletesql){
		echo "Emirler değiştirildi.";
	}
}
else{
	$neworders = serialize($orders);
	$market = mysql_real_escape_string($orders["orders"]["sell"]["market"]);
	$deletesql = mysql_query("DELETE FROM orders WHERE market = '$market' and passkey = '$paskey'");
	$insertsql = mysql_query("insert into orders(id,passkey,market,raw_order) values (NULL,'$paskey','$market','$neworders')");
	if($insertsql&&$deletesql){
		echo "Emirler değiştirildi.";
	}
	}
	
	}else if(mysql_num_rows(mysql_query("select * from orders where passkey='".$paskey."'"))==5){echo "limit_doldu";}else{echo "limitle_ilgili_sorun";}
//              EMİRİ İPTAL ET VE YERİNE GEÇ

}else{}
}
$bot_api_key = $_GET['api_key'];
$bot_api_secret = $_GET['api_secret'];
$bot_type = $_GET['type'];
$bot_passkey = mysql_real_escape_string($_GET['bot']);
$passsql = mysql_query("select passkey,api_key,api_secret from users where passkey = '$bot_passkey'");
if(mysql_num_rows($passsql)!=0){
while($oku = mysql_fetch_array($passsql)){
	if(strlen($oku['passkey'])!=0){
		
		
		$rawdata = file_get_contents("php://input");
		$json = json_decode($rawdata,true);
		//$json_serialized = serialize($json);
		if(strlen($oku['api_key'])==32&&strlen($oku['api_secret'])==32){
			if(isset($_GET["yerine_gec"])&&$_GET["yerine_gec"]=="evet"){
				bittrex($oku["api_key"],$oku["api_secret"],$json, $oku["passkey"], "evet");
			}else{
				bittrex($oku["api_key"],$oku["api_secret"],$json, $oku["passkey"], "hayir");
			}
		}else if(strlen($oku['api_key'])==35&&strlen($oku["api_secret"])==128){
			//poloniex($oku["api_key"],$oku["api_secret"],$json);
		}else{echo "API Key'iniz geçersiz, güncelleyiniz.";}
	}
}
}else{echo "passkey geçersiz!";}
/* EMİRLERİ ALMA */
}else{
if(!empty($_GET['passkey'])){
$passkey = $_GET['passkey'];
$hwid = $_GET['hwid'];
$sql = "SELECT hwid,passkey,api_key,api_secret FROM users WHERE passkey = '$passkey'";
$sql = mysql_query($sql);
if(mysql_num_rows($sql)!=0)
{
    while($oku = mysql_fetch_assoc($sql))
    {	
	if($oku['passkey']==$_GET['passkey']){
	if($oku['hwid']==""){
	$dbConnection = new PDO('mysql:dbname=zeroloss_123;host=localhost;charset=utf8', 'zeroloss', 'C2b40Lj6uj');
	$dbConnection->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
	$dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$dbConnection->query("SET CHARACTER SET utf8");
	$stmt = $dbConnection->prepare("UPDATE `users` SET `hwid` = :hwid WHERE `passkey` = :passkey;");//
	$stmt->execute(array('hwid' => $_GET['hwid'],'passkey' => $oku['passkey']));
	if($stmt){echo "eklendi";}else{echo "eklenemedi";}
	}else{
	if($passkey == $oku['passkey'] && $hwid == $oku['hwid']){
		echo "pass\n";
		if($oku['api_key']&&$oku['api_secret']){
		echo $oku['api_key'] .":". $oku['api_secret'];}else{echo "edit account";}
		}
	else{echo "no";}}
    }else{echo "no";}
	
	}
}
else{
    echo "no";
}
}else{
	echo "no";
}
}}
?>