<?php
@mysql_connect("localhost","zeroloss","C2b40Lj6uj");
mysql_select_db("zeroloss_123");
if(isset($_GET["passkey"])&&isset($_GET["market"])){
	$passkey = mysql_real_escape_string($_GET["passkey"]);
	$market = mysql_real_escape_string($_GET["market"]);
	$sql = mysql_query("select market from orders where passkey = '$passkey' and market = '$market'");
	if(mysql_num_rows($sql)!=0){
		while($oku = mysql_fetch_array($sql)){
			if($oku["market"] !=""){
				if(mysql_query("delete from orders where market = '$market' and passkey = '$passkey'")){
					echo "silindi";
					exit(0);
				}
			}
		}
	}
	
}else{}


?>