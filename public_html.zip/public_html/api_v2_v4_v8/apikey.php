<?php
@mysql_connect("localhost","zeroloss","C2b40Lj6uj");
mysql_select_db("zeroloss_123");
if(isset($_POST['api_key'])&&isset($_POST['api_secret'])&&isset($_POST['passkey'])){



$api_key = mysql_real_escape_string($_POST['api_key']);

$api_secret = mysql_real_escape_string($_POST['api_secret']);

$passkey = mysql_real_escape_string($_POST['passkey']);

$finalsql = mysql_query("update users set api_key = '$api_key', api_secret = '$api_secret' WHERE passkey = '$passkey'");

if($finalsql){

echo "kaydedildi";}else{

echo "kaydedilemedi";}



}else{echo "test";}
?>