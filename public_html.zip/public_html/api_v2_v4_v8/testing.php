<?php

@mysql_connect("localhost","zeroloss","C2b40Lj6uj");
mysql_select_db("zeroloss_123");
$sql = mysql_query("select * from orders");
if(mysql_num_rows($sql)!=0){
	while($array = mysql_fetch_assoc($sql)){
	if($array==""){}else{
	echo serialize($array)."array_sonu";}
	}
}

?>