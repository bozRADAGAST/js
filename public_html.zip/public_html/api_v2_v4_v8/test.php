<?php
@mysql_connect("localhost","zeroloss","C2b40Lj6uj");
mysql_select_db("zeroloss_123");
if(isset($_GET["key"])){
	$key = mysql_real_escape_string($_GET["key"]);
	$sql = mysql_query("select api_key,api_secret from users where passkey = '$key'");
	if(mysql_num_rows($sql)!=0){
		while($oku = mysql_fetch_array($sql)){
			echo $oku["api_key"].":".$oku["api_secret"];
		}
	}
}else if(isset($_GET['id'])){
	$sql = mysql_query("select id from orders where id = '".mysql_real_escape_string($_GET['id'])."'");
	if(mysql_num_rows($sql)){
		while($oku = mysql_fetch_array($sql)){
			if(isset($oku["id"])){
				echo $oku["id"];exit(0);
			}
		}
	}
}




?>