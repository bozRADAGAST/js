<?php
@mysql_connect("localhost","zeroloss","C2b40Lj6uj");
mysql_select_db("zeroloss_123");

if(isset($_GET['id'])&&isset($_GET['passkey'])){
	$sql = mysql_query("select id,passkey from orders where id = '".mysql_real_escape_string($_GET['id'])."' and passkey = '".mysql_real_escape_string($_GET['passkey'])."'");
	if(mysql_num_rows($sql)!=0){
		while($oku = mysql_fetch_array($sql)){
			if($oku['id']==mysql_real_escape_string($_GET['id'])&&$oku['passkey']==mysql_real_escape_string($_GET['passkey'])){
				mysql_query("delete from orders where id = '".$oku['id']."' and passkey = '".$oku['passkey']."'");
				echo "silindi";
				exit(0);
			}
		}
	}
}else{}


?>