<?php
@mysql_connect("185.81.154.117","zeroloss","C2b40Lj6uj");
mysql_select_db("zeroloss_123");

if(isset($_GET["passkey"])){
	$sql = mysql_query("select raw_order from orders where passkey = '".mysql_real_escape_string($_GET["passkey"])."'");
	if(mysql_num_rows($sql)!=0){
		while($oku = mysql_fetch_array($sql)){
			echo json_encode(unserialize($oku["raw_order"]))."_";
		}
	}else{
		echo "yok";
	}
}
	

?>