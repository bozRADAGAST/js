<?php
@mysql_connect("localhost","zeroloss","C2b40Lj6uj");
mysql_select_db("zeroloss_123");

if(isset($_GET["passkey"])){
if(strlen($_GET["passkey"])>1){
$passkey = mysql_real_escape_string($_GET["passkey"]);

if(mysql_num_rows(mysql_query("select passkey from clients where passkey = '".$passkey."'"))!=0){
	if(mysql_num_rows(mysql_query("select uri from clients where passkey='".$passkey."'"))!=0){
		while($oku = mysql_fetch_array(mysql_query("select uri from clients where passkey='".$passkey."'"))){
			if($oku["uri"]!=""){
				echo $oku["uri"];exit(0);
			}else{echo "yok";exit(0);}
		}
	}else{
		echo "yok";
	}

}else{
	$passkey = mysql_real_escape_string($_GET["passkey"]);
	if(mysql_query("insert into clients(passkey) values('".$passkey."')")){echo "eklendi";}else{echo "eklenemedi";}
}
}

}else{}


?>
